﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Diagnostics;

namespace ThermalControl
{
    public partial class plotDisplay : Form
    {
        public plotDisplay()
        {
            InitializeComponent();
            
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSaveChart_Click(object sender, EventArgs e)
        {
            try
            {


                SaveFileDialog saveFile = new SaveFileDialog();

                saveFile.Filter = "Png|*.png";

                saveFile.Title = "Save the Chart Image";

                saveFile.DefaultExt = "*.png";

                saveFile.ShowDialog();

                string imagePath = saveFile.FileName;

                tempChart.SaveImage(imagePath, System.Drawing.Imaging.ImageFormat.Png);
            }
            catch
            {
                MessageBox.Show("Error saving file, please try again--Make sure directory is valid", "Save Error!", MessageBoxButtons.OK);
            }
            
        }

        public void updateChart(double currentProgress)
        {
            
            this.Text = "Plot Display -- Current Progress:  " + currentProgress.ToString() + "%";
            this.Update();
            
        }

        public void plotData(double time, double temp, string seriesName)
        {
            tempChart.Series[seriesName].Points.AddXY(time, temp);

            Application.DoEvents();
            this.Update();
        }

        public void InitializePlotDisplay(List<string> stringArray)
        {
           
            foreach (string stringName in stringArray)
            {
                tempChart.Series.Add(stringName);
                tempChart.Series[stringName].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
                
            }

           
        }

        private void plotDisplay_Load(object sender, EventArgs e)
        {
            tempChart.Series.Clear();
        }

        public void updateValues(double time, double temp, double dtdt, double amps)
        {
            txtdtdt.Text = String.Format("{0:0.000}", dtdt);
            txtTemp.Text = String.Format("{0:0.000}", temp);
            txtTime.Text = String.Format("{0:0.000}", time);
            txtAmps.Text = String.Format("{0:0.000}", amps);

            txtAmps.Update();
            txtTime.Update();
            txtTemp.Update();
            txtdtdt.Update();

        }



        public void CoolingorWarming(bool cool)
        {
            if (cool == true)
            {
                label4.Text = "Amps:  Cooling";
            }

            if (cool == false)
            {
                label4.Text = "Amps:  Warming";
            }
        }
    }
}

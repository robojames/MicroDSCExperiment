﻿#region Using Statements

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Ivi.Visa.Interop;
using Keithley.Ke37XX.Interop;
using System.IO;
using System.Windows.Forms.DataVisualization.Charting;
using System.Diagnostics;
using System.Threading;
using System.Text.RegularExpressions;

#endregion

namespace ThermalControl
{
    public partial class Main : Form
    {
        #region Global Variable Definition / Initialization

        double[] ampArray;
        bool relayFlag = false;
        bool warmFlag = false;

        bool ExperimentReadyFlag = false;
        double setTemp;
        double dUpperCurrent;
        double dLowerCurrent = 0;
        double dtdtCoolRef;
        double constantA;
        int SampleNumber;

        double timeStep;
        double ki;
        double kp;
        double kd;
        double icep = -0.00112603045908184;//-0.0011702;//0.001339294;
        double c0 = 0;
        double c1 = 1.7057035 * Math.Pow(10, -2);
        double c2 = -2.3301759 * Math.Pow(10, -7);
        double c3 = 6.5435585 * Math.Pow(10, -12);
        double c4 = -7.3562749 * Math.Pow(10, -17);
        double c5 = -1.7896001 * Math.Pow(10, -21);
        double c6 = 8.4036165 * Math.Pow(10, -26);
        double c7 = -1.3735879 * Math.Pow(10, -30);
        double c8 = 1.0629823 * Math.Pow(10, -35);
        double c9 = -3.2447087 * Math.Pow(10, -41);

        double c01 = 0;
        double c11 = 1.6977288 * Math.Pow(10, -2);
        double c21 = -4.3514970 * Math.Pow(10, -7);
        double c31 = -1.5859697 * Math.Pow(10, -10);
        double c41 = -9.250287 * Math.Pow(10, -14);
        double c51 = -2.6084314 * Math.Pow(10, -17);
        double c61 = -4.1360199 * Math.Pow(10, -21);
        double c71 = -3.4034030 * Math.Pow(10, -25);
        double c81 = -1.1564890 * Math.Pow(10, -29);
        double c91 = 0;

        string channelNumber;

        List<string> ListPlot = new List<string>();

        public void InitializeValues()
        {
            
            txtmaxCurrent.Text = "7.0";
            txtTimeStep.Text = "0.005";

            ListPlot.Add("Temperature");
            ListPlot.Add("dTdt");

            txtkP.Text = "1.625";
            txtkI.Text = "0.08155";
            txtkd.Text = "0.425";
         

            txtChannelNumber.Text = "6006";
            txtPowerRun.Text = "5";

            txtExperimentConstantAA.Text = "0";
          
            txtExperimentDTref.Text = "1.0";
            txtExperimentSampleNumber.Text = "500";
            txtExperimentTset.Text = "25";
            radioButton1.Checked = true;
 
            txtExperimentTset.Enabled = false;
            btnExperimentReady.Enabled = false;

            
        }


        public Main()
        {
            InitializeComponent();
        }

        private void Main_Load(object sender, EventArgs e)
        {
            InitializeValues();
        }

        #endregion

        #region Experiments
        // **********************************************************************************************
        // ****************************** LINEAR COOLING PROFILE ****************************************
        // **********************************************************************************************
        public void LinearCooling(double[] ampArrayD)
        {

            plotDisplay tempChart = new plotDisplay();

            tempChart.Show();

            Hardware LinearCoolingSetup = new Hardware();

            Ke37XX DMM = LinearCoolingSetup.InitializeDMM(timeStep, channelNumber);

            FormattedIO488 ps1 = LinearCoolingSetup.InitializeAgilent6032();

            FormattedIO488 ps2 = LinearCoolingSetup.InitializeAgilent6760();

            int ibufferSize = SampleNumber;
            int frontEndScan = 26;

            DMM.Scan.ScanCount = 1;

            string sbufferName = "Mybuffer";

            DMM.Measurement.Buffer.Create(sbufferName, ibufferSize);

            DMM.System.DirectIO.IO.Timeout = 10000;

            double currentProgress;
            double[] readings = new double[SampleNumber + frontEndScan + 25000];
            double[] dTdt = new double[SampleNumber + frontEndScan + 25000];
            double[] time = new double[SampleNumber + frontEndScan + 25000];
            double[] temp = new double[SampleNumber + frontEndScan + 25000];
            double[] timeDiff = new double[SampleNumber + frontEndScan + 25000];
            double[] data = new double[SampleNumber + frontEndScan + 25000];
            double[] dERR = new double[SampleNumber + frontEndScan + 25000];
            double[] ampArrayToWrite = new double[SampleNumber + frontEndScan + 25000];
            double[] dTdterr = new double[SampleNumber + frontEndScan + 25000];
            double[] dTdtint = new double[SampleNumber + frontEndScan + 25000];
            double[] dtdtTEST = new double[SampleNumber + frontEndScan + 25000];
            double aSet;
            double dTdtref = dtdtCoolRef;
            double aWarmSet;

            tempChart.InitializePlotDisplay(ListPlot);

            DMM.Timer.Reset();

            DMM.Display.Clear();

            DMM.Display.Text = "Scanning...";

            int p = 0;
            int l = 0;
            int kk = 0;

            if (warmFlag == true)
            {
                // slow warming logic

                while (warmFlag == true)
                {

                    

                    time[p] = DMM.Timer.Measure();

                    DMM.Scan.Execute(sbufferName);

                    readings = DMM.Measurement.Buffer.ReadingData.GetFormattedReadings(sbufferName, 1, 1);

                    foreach (double reading in readings)
                        temp[p] = getTemp(reading);

                    if (p > 9)
                    {
                        kk = p - 2;
                        timeDiff[p] = time[p] - time[p - 1];


                        dTdt[p] = (8 * (temp[kk + 1] - temp[kk - 1]) + (temp[kk - 2] - temp[kk + 2])) / (12 * (timeDiff[p]));
                        
                        Debug.WriteLine(dTdt[p].ToString());

                        dTdterr[p] = dTdtref - dTdt[p];

                        dERR[p] = (8 * (dTdterr[p + 1] - dTdterr[p - 1]) + (dTdterr[p - 2] - dTdterr[p + 2])) / (12 * (timeDiff[p]));

                        dTdtint[p] = dTdtint[p - 1] + dTdterr[p];
                    }

                    if (checkBoxTemp.Checked == true)
                        tempChart.plotData(time[p], temp[p], "Temperature");
                    

                    if (checkBoxDtdt.Checked == true)
                        tempChart.plotData(time[p], dTdt[p], "dTdt");

                    // Apply new current -- Might need to change this to subtract an amount of current based on it's current value;
                    aWarmSet = 3 - (1.2 * dTdterr[p] + 0.07 * dERR[p] + 0.0035*dTdtint[p]);

                    if (aWarmSet >= 4)
                        aWarmSet = 4;

                    if (aWarmSet <= 0)
                    {
                        aWarmSet = 0;
                    }

                    Debug.WriteLine("newA: " + aWarmSet.ToString() + "     dtdterr: " + dTdterr[p].ToString() + "    " + " dERR: " + dERR[p].ToString() + "     " + " dtdtint: " + dTdtint[p].ToString());

                    ps1.IO.WriteString("ISET " + aWarmSet.ToString() + "\n");

                    if (temp[p] <= -20)
                    {
                        warmFlag = false;
                    }

                    tempChart.updateValues(time[p], temp[p], dTdt[p], aWarmSet);

                    p++;

                    if (aWarmSet == 0)
                        l++;
                   
                    if (l > 49) // If the current has been set to 0 or less than 0 for 50 times then break the while/loop
                        warmFlag = false;

                    
                }

            }

            relayFlag = false;

            relayFlag = switchRelay(ps2, relayFlag);

            // Get Initial Baseline Reading
            for (int i = p; i <= frontEndScan - 1 + p; i++)
            {
                
                time[i] = DMM.Timer.Measure();

                DMM.Scan.Execute(sbufferName);

                readings = DMM.Measurement.Buffer.ReadingData.GetFormattedReadings(sbufferName, 1, 1);

                foreach (double reading in readings)
                {
                    temp[i] = getTemp(reading);
                }

                dTdt[i] = 0;

                if (checkBoxTemp.Checked == true)
                    tempChart.plotData(time[i], temp[i], "Temperature");
                

                if (checkBoxDtdt.Checked == true)
                    tempChart.plotData(time[i], dTdt[i], "dTdt");
                

                currentProgress = (i * (Math.Pow((double)SampleNumber + frontEndScan - 1, -1))) * 100;//(double)((i/iscanCount) * 100);

                currentProgress = (double)Math.Round((decimal)currentProgress, 2);

                ampArrayToWrite[i] = 0;

                tempChart.CoolingorWarming(relayFlag);

                tempChart.updateChart(currentProgress);

                tempChart.updateValues(time[i], temp[i], dTdt[i], 0);

            }

            // Begin Linear Cooling

            double iSetAmp = 0.1646 * Math.Pow(dTdtref, 2) + 0.4243 * dTdtref + 1.0;

            ps1.IO.WriteString("ISET " + iSetAmp + "\n");

            for (int i = frontEndScan + p; i <= SampleNumber + frontEndScan - 1 + p; i++)
            {
                time[i] = DMM.Timer.Measure();

                DMM.Scan.Execute(sbufferName);

                readings = DMM.Measurement.Buffer.ReadingData.GetFormattedReadings(sbufferName, 1, 1);

                foreach (double reading in readings)
                {
                    temp[i] = getTemp(reading);
                }

                int j = i - 2;

                timeDiff[i] = time[i] - time[i - 1];

                dTdt[i] = (8 * (temp[j + 1] - temp[j - 1]) + (temp[j - 2] - temp[j + 2])) / (12 * (timeDiff[i]));

                dtdtTEST[i] = (dTdt[i] + dTdt[i - 1] + dTdt[i - 2] + dTdt[i - 3] + dTdt[i - 4] + dTdt[i - 5] + dTdt[i - 6] + dTdt[i - 7] + dTdt[i - 8]) / 9;

                dTdterr[i] = dTdtref + dtdtTEST[i];

                dERR[i] = (8 * (dTdterr[j + 1] - dTdterr[j - 1]) + (dTdterr[j - 2] - dTdterr[j + 2])) / (12 * (timeDiff[i]));

                dTdtint[i] = dTdtint[i - 1] + dTdterr[i];
               // MONITOR THIS SHIT

               // if (time[i] < 50)
               // {

                    if ((dTdtint[i] * ki) >= 9 | (dTdtint[i] * ki) <= -9)
                        dTdtint[i] = 0;

                

                aSet = ControlSysCR(dTdterr[i], dTdtint[i], dERR[i]);

                   
                if (chkboxImport.Checked == true && i <= ampArrayD.Length)
                    {
                        ps1.IO.WriteString("ISET " + ampArrayD[i].ToString() + "\n");
                        ampArrayToWrite[i] = ampArrayD[i];
                    }
                   
                else
                    {
                        if (dTdt[i] >= 3)
                            aSet = 0;
                        ps1.IO.WriteString("ISET " + aSet.ToString() + "\n");
                        ampArrayToWrite[i] = aSet;
                    }

                if (checkBoxTemp.Checked == true)
                    tempChart.plotData(time[i], temp[i], "Temperature");
                    
              
                if (checkBoxDtdt.Checked == true)
                    tempChart.plotData(time[i], dTdt[i], "dTdt");
                    

                currentProgress = (i * (Math.Pow((double)SampleNumber + frontEndScan - 1, -1))) * 100;//(double)((i/iscanCount) * 100);

                currentProgress = (double)Math.Round((decimal)currentProgress, 2);

                tempChart.CoolingorWarming(relayFlag);

                tempChart.updateChart(currentProgress);

                tempChart.updateValues(time[i], temp[i], dTdt[i], aSet);
            }

            if (checkBox2.Checked == true)
            {
                ps1.IO.WriteString("ISET 7.0\n");

                int i = SampleNumber + frontEndScan;

                int k = 0;
                
                while (temp[i-5] <= 15)
                {

                    time[i] = DMM.Timer.Measure();

                    DMM.Scan.Execute(sbufferName);

                    readings = DMM.Measurement.Buffer.ReadingData.GetFormattedReadings(sbufferName, 1, 1);

                    foreach (double reading in readings)
                        temp[i] = getTemp(reading);
                

                    int j = i - 2;

                    timeDiff[i] = time[i] - time[i - 1];

                    dTdt[i] = (8 * (temp[j + 1] - temp[j - 1]) + (temp[j - 2] - temp[j + 2])) / (12 * (timeDiff[i]));

                    dTdterr[i] = dTdtref - dTdt[i];

                    dERR[i] = (8 * (dTdterr[j + 1] - dTdterr[j - 1]) + (dTdterr[j - 2] - dTdterr[j + 2])) / (12 * (timeDiff[i]));

                    dTdtint[i] = dTdtint[i - 1] + dTdterr[i];

                    aSet = 7 - k * 0.0055; // 0.00105

                    if (aSet <= 0 && relayFlag == true)
                    {
                       k = 0;
                       relayFlag = switchRelay(ps2, relayFlag);

                    }

                    if (relayFlag == false)
                        aSet = k * 0.0025; // 0.00085
                    
                    ps1.IO.WriteString("ISET " + aSet.ToString() + "\n");

                    ampArrayToWrite[i] = aSet;

                    if (checkBoxTemp.Checked == true)
                        tempChart.plotData(time[i], temp[i], "Temperature");
                    

                    if (checkBoxDtdt.Checked == true)
                        tempChart.plotData(time[i], dTdt[i], "dTdt");

                    tempChart.CoolingorWarming(relayFlag);

                    tempChart.updateValues(time[i], temp[i], dTdt[i], aSet);

                    i++;

                    k++;
                }

                ps1.IO.WriteString("ISET 0.0\n");

                DMM.Display.Clear();

                DMM.Display.Text = "Finished!";

                writeFile(temp, time, dTdt, i, ampArrayToWrite);
                
                DMM.Measurement.Buffer.Clear(sbufferName);

                Cleanup();
            }
            else
            {
                ps1.IO.WriteString("ISET 0.0\n");


                switchRelay(ps2, relayFlag); // Turns relay back off

                DMM.Display.Clear();

                DMM.Display.Text = "Finished!";

                writeFile(temp, time, dTdt, SampleNumber + frontEndScan, ampArrayToWrite); // Writes data to .csv file

                DMM.Measurement.Buffer.Clear(sbufferName);

                Cleanup();
            }
        }

        // **********************************************************************************************
        // ***************************** BASIC MEASUREMENT PROFILE **************************************
        // **********************************************************************************************
        private void btnBasicMeasure_Click(object sender, EventArgs e)
        {
            BasicMeasurement();
        }

        public void BasicMeasurement()
        {
            plotDisplay tempChart = new plotDisplay();

            tempChart.Show();

            Hardware basicSetup = new Hardware();

            Ke37XX DMM = basicSetup.InitializeDMM(timeStep, channelNumber);

            FormattedIO488 pS1 = basicSetup.InitializeAgilent6032();

            FormattedIO488 pS2 = basicSetup.InitializeAgilent6760();

            int iscanCount = SampleNumber;
            int ibufferSize = iscanCount;

            double tempValue;
            double amps = constantA;
            double currentProgress;
            double[] dTdt = new double[iscanCount + 1];
            double[] time = new double[iscanCount + 1];
            double[] temp = new double[iscanCount + 1];
            double[] timeDiff = new double[iscanCount + 1];
            double[] data = new double[iscanCount + 1];
            double[] readings = new double[iscanCount + 1];
            double[] ampstoWrite = new double[iscanCount + 1];
            double AmbTemp = double.Parse(txtSensorTC.Text);
            string sbufferName = "Mybuffer";

            DMM.Display.Clear();

            DMM.Display.Text = "Scanning...";

            DMM.Scan.ScanCount = 1;

            DMM.Measurement.Buffer.Create(sbufferName, ibufferSize);

            DMM.System.DirectIO.IO.Timeout = 10000;

            DMM.Timer.Reset();

            relayFlag = switchRelay(pS2, relayFlag);

            tempChart.InitializePlotDisplay(ListPlot);

            for (int i = 0; i <= iscanCount; i++)
            {

                pS1.IO.WriteString("ISET " + constantA.ToString() + "\n");

                time[i] = DMM.Timer.Measure();

                DMM.Scan.Execute(sbufferName);

                ampstoWrite[i] = amps;
                readings = DMM.Measurement.Buffer.ReadingData.GetFormattedReadings(sbufferName, 1, 1);

                foreach (double reading in readings)
                {
                    if (checkboxSensorRead.Checked == true)
                    {
                        //temp[i] = -1 * (0.9237 - 0.0041 * AmbTemp + 0.00004 * Math.Pow(AmbTemp, 2) - reading) / (0.0305 + 0.000044 * AmbTemp - 1.1 * Math.Pow(10, -6) * Math.Pow(AmbTemp, 2));
                        tempValue = -1 * (161.29 * (-reading + 0.16 * 4.5)) / 4.5;

                        temp[i] = tempValue / (1.0546 - 0.00216 * AmbTemp);
                    }
                    else
                    {
                        temp[i] = getTemp(reading);
                    }

                    Debug.WriteLine(reading.ToString());
                }

                Array.Clear(readings, 0, readings.Length);

                if (i > 5)
                {
                    int j = i - 2;

                    timeDiff[i] = time[i] - time[i - 1];

                    dTdt[i] = (8 * (temp[j + 1] - temp[j - 1]) + (temp[j - 2] - temp[j + 2])) / (12 * (timeDiff[i]));
                }


                if (checkBoxTemp.Checked == true)
                    tempChart.plotData(time[i], temp[i], "Temperature");
                
                if (checkBoxDtdt.Checked == true)
                    tempChart.plotData(time[i], dTdt[i], "dTdt");
                
                currentProgress = (i * (Math.Pow((double)iscanCount, -1))) * 100;//(double)((i/iscanCount) * 100);

                currentProgress = (double)Math.Round((decimal)currentProgress, 2);

                tempChart.updateChart(currentProgress);

                tempChart.updateValues(time[i], temp[i], dTdt[i], amps);
            }

            pS1.IO.WriteString("ISET 0.0\n");

            switchRelay(pS2, relayFlag); // Turns relay back off

            DMM.Display.Clear();

            DMM.Display.Text = "Finished!";

            writeFile(temp, time, dTdt, iscanCount, ampstoWrite); // Writes data to .csv file

            Cleanup();
        }

        private void btnMeasure_Click(object sender, EventArgs e)
        {


            btnMeasure.Enabled = false;

            Hardware PowerMeasure = new Hardware();

            FormattedIO488 PS1 = PowerMeasure.InitializeAgilent6760();

            Stopwatch timer = new Stopwatch();
            int measureDelay = 1000;
            double timeToStop = double.Parse(txtPowerRun.Text);
            double[] time = new double[10000];
            double[] reading = new double[10000];
            double[] filler = new double[10000];
            double[] ampstoWrite = new double[10000];
            timer.Start();
            int i = 0;
            int Progress;

            while (timer.Elapsed.TotalMinutes < timeToStop)
            {
                Progress = (int)Math.Round((timer.Elapsed.TotalMinutes / timeToStop) * 100, 0);

                PowerProgress.Value = Progress;

                Thread.Sleep(measureDelay);
                time[i] = timer.Elapsed.TotalSeconds;
                PS1.IO.WriteString("MEAS:VOLT? (@1)\n");
                reading[i] = double.Parse(PS1.IO.ReadString(400));

                i++;

                if (i == 9990)
                    break;
            }


            writeFile(reading, time, filler, 10000, ampstoWrite);

            btnMeasure.Enabled = true;

            PowerProgress.Value = 0;
        }

        #endregion

        #region Frequently Used SubRoutines

        

        public double ControlSysSetTemp(double setTemp, double currentTemp)
        {
            double newA = 0;

            return newA;
        }

        public bool switchRelay(FormattedIO488 ps2, bool flag)
        {
            if (flag == false)
            {
                ps2.IO.WriteString("VOLT 9.0,(@2)\n");
                ps2.IO.WriteString("OUTP ON,(@2)\n");
                flag = true;
                
                return flag;
            }

            if (flag == true)
            {
                ps2.IO.WriteString("OUTP OFF,(@2)\n");
                flag = false;
                
                return flag;
            }

            return flag;
        }



        public double ControlSysCR(double dTdterr, double dTdtint, double dERR)
        {
            double newA;

            newA = ((kp) * dTdterr + ki * dTdtint + dERR * kd);

            Debug.WriteLine("New Amp: " + newA.ToString() + "  Kterm: " + ((kp*dTdterr).ToString()) + " Iterm:  " + ((ki*dTdtint).ToString()) + " Dterm: " + (dERR*kd).ToString());

            if (newA >= dUpperCurrent)
                newA = dUpperCurrent;


            if (newA <= dLowerCurrent)
                newA = dLowerCurrent;

            return newA;
        }

        public double getTemp(double volts)
        {
            double temp;

            volts = (volts - icep) * Math.Pow(10, 6);

            if (volts >= 0)
                temp = c0 + c1 * volts + c2 * Math.Pow(volts, 2) + c3 * Math.Pow(volts, 3) + c4 * Math.Pow(volts, 4) + c5 * Math.Pow(volts, 5) + c6 * Math.Pow(volts, 6) + c7 * Math.Pow(volts, 7) + c8 * Math.Pow(volts, 8) + c9 * Math.Pow(volts, 9);
            else
                temp = c01 + c11 * volts + c21 * Math.Pow(volts, 2) + c31 * Math.Pow(volts, 3) + c41 * Math.Pow(volts, 4) + c51 * Math.Pow(volts, 5) + c61 * Math.Pow(volts, 6) + c71 * Math.Pow(volts, 7) + c81 * Math.Pow(volts, 8) + c91 * Math.Pow(volts, 9);
            return temp;
        }

        public double[] importCurrentProfile()
        {
            try
            {
                OpenFileDialog openFile = new OpenFileDialog();
                
                int samples = int.Parse(txtExperimentSampleNumber.Text);    

                openFile.Filter = "CSV|*.csv";
                openFile.Title = "Select Data File to Import";
                openFile.DefaultExt = "*.csv";

                openFile.ShowDialog();

                string directory = openFile.FileName;
                
                List<string> CurrentImporte = new List<string>();
                
                string line;
                
                TextReader dataRead = new StreamReader(directory);

                

                while ((line = dataRead.ReadLine()) != null)
                    CurrentImporte.Add(line);
                

                

                int j = 0;

                List<double> AmpArray = new List<double>();

                foreach (string dataEntry in CurrentImporte)
                {
                    string[] placeHolder = dataEntry.Split(',');

                    if (j > 0)
                        AmpArray.Add(double.Parse(placeHolder[0]));
                    
                        
                    

                    j++;
                }

                ampArray = new double[AmpArray.Count];
                
                int k = 0;

                foreach (double amp in AmpArray)
                {
                    ampArray[k] = amp;
                    k++;
                }

                
            }
            catch (Exception error)
            {
                MessageBox.Show("Error Importing/Reading from selected file");
                MessageBox.Show(error.ToString());
            }

            return ampArray;
        }


        public void writeFile(double[] tempArray, double[] timeArray, double[] dTdt, int scanCount, double[] ampArraytoWrite)
        {

            try
            {
                SaveFileDialog saveFile = new SaveFileDialog();

                saveFile.Filter = "CSV|*.csv";
                saveFile.Title = "Save the data file:";
                saveFile.DefaultExt = "*.csv";

                saveFile.ShowDialog();

                string directory = saveFile.FileName;

                TextWriter dataWrite = new StreamWriter(directory);

                dataWrite.WriteLine("Current" + "," + "Time" + "," + "Temperature" + "," + "dT/dt");

                for (int i = 1; i < scanCount; i++)
                    dataWrite.WriteLine(ampArraytoWrite[i] + "," + timeArray[i] + "," + tempArray[i] + "," + dTdt[i]);

                dataWrite.Close();
            }
            catch
            {
                MessageBox.Show("Error saving file, or writing was canceled ", "Error!", MessageBoxButtons.OK);
            }
        }

       


        #endregion

        #region User Logic

        private void chkboxImport_CheckedChanged(object sender, EventArgs e)
        {
            if (chkboxImport.Checked == true)
            {
                radioButton1.Enabled = false;
                radioButton2.Enabled = false;
                txtExperimentConstantAA.Enabled = false;
                txtExperimentDTref.Enabled = false;
            }

            if (chkboxImport.Checked == false)
            {
                radioButton1.Enabled = true;
                radioButton2.Enabled = true;
                txtExperimentConstantAA.Enabled = true;
                txtExperimentDTref.Enabled = true;
            }
        }

        private void btnExperimentStart_Click(object sender, EventArgs e)
        {
            btnExperimentStart.Enabled = false;
            

            if (radioButton1.Checked == true && checkBox1.Checked == false && checkBox2.Checked == false)
            {
                BasicMeasurement();
            }

            if (radioButton2.Checked == true && checkBox1.Checked == false)
            {
                LinearCooling(ampArray);
            }

            if (radioButton2.Checked == true && checkBox1.Checked == true && chkboxImport.Checked == false)
            {
                btnExperimentReady.Enabled = true;

                bgWorkerWarmLinCool.RunWorkerAsync();

                while (ExperimentReadyFlag == false)
                {
                    Application.DoEvents();
                }
                warmFlag = true;

                LinearCooling(ampArray);

            }

            if (radioButton2.Checked == true && checkBox1.Checked == true && chkboxImport.Checked == true)
            {
                double[] ampArrayD;

                ampArrayD = importCurrentProfile();

                btnExperimentReady.Enabled = true;

                bgWorkerWarmLinCool.RunWorkerAsync();

                while (ExperimentReadyFlag == false)
                {
                    Application.DoEvents();
                }

                LinearCooling(ampArray);

            }


            btnExperimentStart.Enabled = true;
        }



        private void btnExperimentReady_Click(object sender, EventArgs e)
        {
            ExperimentReadyFlag = true;
        }


        private void txtExperimentSampleNumber_TextChanged(object sender, EventArgs e)
        {
            try
            {
                SampleNumber = int.Parse(txtExperimentSampleNumber.Text);
            }
            catch
            {
                MessageBox.Show("Parse Error!", "Error!", MessageBoxButtons.OK);
            }
        }

        private void txtExperimentDTref_TextChanged(object sender, EventArgs e)
        {
            try
            {
                dtdtCoolRef = double.Parse(txtExperimentDTref.Text);
            }
            catch
            {
                MessageBox.Show("Parse Error!", "Error!", MessageBoxButtons.OK);
            }
        }

        private void txtExperimentConstantAA_TextChanged(object sender, EventArgs e)
        {
            try
            {
                constantA = double.Parse(txtExperimentConstantAA.Text);
            }
            catch
            {
                MessageBox.Show("Parse Error!", "Error!", MessageBoxButtons.OK);
            }
        }

        private void txtExperimentTset_TextChanged(object sender, EventArgs e)
        {
            try
            {
                setTemp = double.Parse(txtExperimentTset.Text);
            }
            catch
            {
                MessageBox.Show("Parse Error!", "Error!", MessageBoxButtons.OK);
            }
        }

        private void txtPowerRun_TextChanged(object sender, EventArgs e)
        {
            try
            {
                int.Parse(txtPowerRun.Text);
            }
            catch
            {
                MessageBox.Show("Parse Error!", "Error!", MessageBoxButtons.OK);
            }

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
                txtExperimentDTref.Enabled = false;
                txtExperimentConstantAA.Enabled = true;
            }
            else
            {
                txtExperimentConstantAA.Enabled = false;
            }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked == true)
            {
                txtExperimentDTref.Enabled = true;
                txtExperimentConstantAA.Enabled = false;
            }
            else
            {
                txtExperimentConstantAA.Enabled = true;
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                txtExperimentTset.Enabled = true;
            }
            else
            {
                txtExperimentTset.Enabled = false;
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked == true)
            {
               
            }
            else
            {
                
            }
        }


        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AboutBox1 aboutBox = new AboutBox1();

            aboutBox.Show();
        }

        private void txtmaxCurrent_TextChanged(object sender, EventArgs e)
        {
            try
            {
                dUpperCurrent = double.Parse(txtmaxCurrent.Text);
                
            }
            catch
            {
                MessageBox.Show("Error:  Parse Error", "Error!", MessageBoxButtons.OK);
            }

        }

        private void Main_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void checkBoxTemp_CheckedChanged(object sender, EventArgs e)
        {
            ListPlot.Clear();

            if (checkBoxDtdt.Checked == true)
            {
                ListPlot.Add("dTdt");
            }


            if (checkBoxTemp.Checked == true)
            {
                ListPlot.Add("Temperature");
            }
        }

        private void checkBoxDtdt_CheckedChanged(object sender, EventArgs e)
        {
            ListPlot.Clear();

            if (checkBoxDtdt.Checked == true)
            {
                ListPlot.Add("dTdt");
            }

            if (checkBoxTemp.Checked == true)
            {
                ListPlot.Add("Temperature");
            }

        }

        private void txtTimeStep_TextChanged(object sender, EventArgs e)
        {
            try
            {
                timeStep = double.Parse(txtTimeStep.Text);
            }
            catch
            {
                MessageBox.Show("Parse Error!", "Error!", MessageBoxButtons.OK);
                txtTimeStep.Text = "0.005";
            }


        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtkI_TextChanged(object sender, EventArgs e)
        {
            try
            {
                ki = double.Parse(txtkI.Text);
            }
            catch
            {
                MessageBox.Show("Parse Error", "Error!", MessageBoxButtons.OK);
                InitializeValues();
            }
        }

        private void txtkP_TextChanged(object sender, EventArgs e)
        {
            try
            {
                kp = double.Parse(txtkP.Text);
            }
            catch
            {
                MessageBox.Show("Parse Error", "Error!", MessageBoxButtons.OK);
                InitializeValues();
            }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            try
            {
                kd = double.Parse(txtkd.Text);
            }
            catch
            {
                MessageBox.Show("Parse Error!", "Error!", MessageBoxButtons.OK);
                InitializeValues();
            }
        }

        private void txtChannelNumber_TextChanged(object sender, EventArgs e)
        {
            try
            {
                channelNumber = txtChannelNumber.Text;

                if (channelNumber.Length.Equals(4) == false)
                {
                    MessageBox.Show("Channel #'s must be 4 digits long, ie -- 6006");
                    txtChannelNumber.Text = "6006";
                }
            }
            catch
            {
                MessageBox.Show("Parse Error!", "Error!", MessageBoxButtons.OK);
            }
        }

        #endregion

        #region Cleanup/Disposal Routines

        public void Cleanup()
        {
            ListPlot.Clear();
            InitializeValues();
            //bgWorkerWarmLinCool.Dispose();
            
        }



        #endregion

        #region Help Boxes

        private void basicToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Takes a specified number of measurements out of channel 6006, converting EMF's into temperature (Deg C) using a fixed ice point reference", "Explanation", MessageBoxButtons.OK);
        }



        private void linearCoolingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Produces a linear cooling rate, utilizing ki, kp, and kd.  Program first takes 100 measurements, then proceeds to match the given cooling rate.");
        }

        #endregion

        #region Warm/Lin/Cool + BGWorker Thread

        private void bgWorkerWarmLinCool_DoWork(object sender, DoWorkEventArgs e)
        {
            Hardware warmLinCool = new Hardware();
            FormattedIO488 ps1 = warmLinCool.InitializeAgilent6032();
            FormattedIO488 ps2 = warmLinCool.InitializeAgilent6760();

            Ke37XX DMM = warmLinCool.InitializeDMM(timeStep,channelNumber);

            warmingProfile(ps1,ps2,DMM);
        }

        public void warmingProfile(FormattedIO488 ps1, FormattedIO488 ps2, Ke37XX DMM)
        {
            
            int iscanCount = 50000;
         
            double[] dTdt = new double[iscanCount + 1];
            double[] time = new double[iscanCount + 1];
            double[] temp = new double[iscanCount + 1];
            double[] timeDiff = new double[iscanCount + 1];
            double[] data = new double[iscanCount + 1];
            double[] readings = new double[iscanCount + 1];
            double amps;

            string sbufferName = "Mybuffer";
            DMM.Measurement.Buffer.Clear(sbufferName);

            DMM.Display.Clear();

            DMM.Display.Text = "Scanning...";

            DMM.Scan.ScanCount = 1;


            DMM.Measurement.Buffer.Create(sbufferName, 50000);

            DMM.System.DirectIO.IO.Timeout = 10000;

            DMM.Timer.Reset();

            int i = 0;

            while (ExperimentReadyFlag == false)
            {
                time[i] = DMM.Timer.Measure();

                DMM.Scan.Execute(sbufferName);

                dTdt[i] = 0;

                readings = DMM.Measurement.Buffer.ReadingData.GetFormattedReadings(sbufferName, 1, 1);

                foreach (double reading in readings)
                    temp[i] = getTemp(reading);

                DMM.Display.Clear();
              
                DMM.Display.Text = "Temp: " + temp[i] + " C";

                amps = newAWarming(setTemp, temp[i]);

                ps1.IO.WriteString("ISET " + amps + "\n");

                i++;
            }

            

            DMM.Display.Clear();

            DMM.Display.Text = "Finished!";
        }

        public double newAWarming(double setTemp, double T)
        {
            double tErr = setTemp - T;
           
            double newA;

            newA = tErr * 0.25;

            if (newA >= 6)
                newA = 6;
            
            if (newA <= 0)
                newA = 0;
            
            return newA;
        }
        #endregion

    }
}

